import Vue from "vue";
import VueRouter from "vue-router";
import TvShowDashboard from "@/views/TvShowDashboard.vue";
import TvShowDetail from "@/views/TvShowDetail.vue";
Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "TvShowDashboard",
    component: TvShowDashboard
  },
  {
    path: "/search",
    name: "TvShowSearch",
    component: () => import("@/views/TvShowSearch.vue")
  },
  {
    path: "/favourites",
    name: "TvShowFavourites",
    component: () => import("@/views/TvShowFavourites.vue")
  },
  {
    path: "/detail",
    name: "TvShowDetail",
    component: TvShowDetail
  },
  {
    path: "/about",
    name: "About",
    component: () => import("../views/About.vue")
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
