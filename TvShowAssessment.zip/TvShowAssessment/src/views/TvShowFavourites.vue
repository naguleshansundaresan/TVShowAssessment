<template>
  <v-container>
    <v-row justify="center">
      <h2 class="ma-4 white--text">Favourites</h2>
    </v-row>
    <v-row>
      <v-flex
        md3
        v-for="(tvShow, index) in tvShowFavouriteList"
        :key="index"
        class="pa-5"
      >
        <span v-if="tvShow">
          <ShowCard :show="tvShow" :key="tvShowFavouriteList.length"></ShowCard>
        </span>
      </v-flex>
    </v-row>
    <v-dialog v-model="dialog" max-width="300">
      <v-card
        style="background-color: #09203f;font-size: 15px;"
        class="customed"
      >
        <v-card-title class="red--text">Alert</v-card-title>
        <v-card-text class="grey--text">
          Sorry !!! No shows found... Try after adding favourite shows
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="grey" @click="dialog = !dialog">close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import ShowCard from "@/components/tv-show-components/ShowCard.vue";
export default {
  name: "TvShowFavourites",
  components: {
    ShowCard
  },
  data() {
    return {
      dialog: false,
      tvShowFavouriteList: []
    };
  },
  methods: {
    getFavouriteShows() {
      this.tvShowFavouriteList = this.$store.getters.getFavouriteList;
      if (this.tvShowFavouriteList.length == 0) {
        this.dialog = true;
      }
    }
  },
  created() {
    this.getFavouriteShows();
  }
};
</script>
