<template>
  <v-container>
    <v-row justify="center">
      <v-flex md6>
        <v-text-field
          dark
          class="white--text mt-5 px-1"
          dense
          color="cyan darken-2"
          outlined
          height="40px"
          placeholder="Search Shows"
          v-model="searchedTvShow"
        ></v-text-field>
      </v-flex>
      <v-flex md6>
        <v-btn
          id="search-btn"
          shaped
          outlined
          height="40px"
          color="cyan darken-2"
          class="white--text mt-5"
          @click="getSearchedTvShow"
        >
          <v-icon>mdi-database-search</v-icon>Search
        </v-btn>
      </v-flex>
    </v-row>
    <v-row>
      <v-flex
        md3
        v-for="(tvShow, index) in tvShowSearchList"
        :key="index"
        class="pa-5"
      >
        <span v-if="tvShow.show">
          <ShowCard :show="tvShow.show"></ShowCard>
        </span>
      </v-flex>
    </v-row>
    <v-dialog v-model="dialog" max-width="300">
      <v-card
        style="background-color: #09203f;font-size: 15px;"
        class="customed"
      >
        <v-card-title class="red--text">Alert</v-card-title>
        <v-card-text class="grey--text"
          >Sorry !!! No data found... Try other search keywords</v-card-text
        >
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="grey" @click="dialog = !dialog">close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-container>
</template>

<script>
import ShowCard from "@/components/tv-show-components/ShowCard.vue";
import { getShowsByName } from "@/services/show.service.js";
export default {
  name: "TvShowSearch",
  components: {
    ShowCard
  },
  data() {
    return {
      dialog: false,
      searchedTvShow: "",
      tvShowSearchList: []
    };
  },
  methods: {
    async getSearchedTvShow() {
      await getShowsByName(this.searchedTvShow)
        .then(response => {
          this.tvShowSearchList = response.data;
          this.checkDialog();
        })
        .catch();
    },
    checkDialog() {
      if (this.tvShowSearchList.length == 0) {
        this.dialog = true;
      }
    }
  }
};
</script>
