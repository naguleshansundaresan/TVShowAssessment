<template>
  <div fluid class="mb-10">
    <v-img src="@/assets/background.jpg" height="250"></v-img>
    <v-container class="white--text hidden sm-and-down" fluid>
      <span>
        <h3 class="mx-4 mt-8 mb-4">Popular Shows</h3>
      </span>
      <CardSlides :showList="popularShowsList"></CardSlides>
      <ShowList :tvShowList="tvShowsDashboardList" :key="success"></ShowList>
    </v-container>
  </div>
</template>

<script>
import { getAllShows } from "@/services/show.service.js";
import CardSlides from "@/components/tv-show-components/CardSlides.vue";
import ShowList from "@/components/tv-show-components/ShowList.vue";
export default {
  name: "TvShowDashboard",
  components: {
    CardSlides,
    ShowList
  },
  data() {
    return {
      success: false,
      popularShowsList: [],
      tvShowsDashboardList: []
    };
  },
  methods: {
    getAllTvShows() {
      getAllShows()
        .then(response => {
          let tvShows = response.data;
          this.getTvShowsDashboardList(tvShows);
        })
        .catch();
    },
    getTvShowsDashboardList(tvShows) {
      tvShows.forEach(show => {
        if (show.rating.average) {
          this.tvShowsDashboardList.push(show);
          if (show.rating.average > 8.5) this.popularShowsList.push(show);
          this.success = true;
        }
      });
      this.sortTvShow();
    },
    sortTvShow() {
      this.tvShowsDashboardList.sort((tvShow1, tvShow2) => {
        return tvShow2.rating.average - tvShow1.rating.average;
      });
    }
  },
  created() {
    this.getAllTvShows();
  }
};
</script>
