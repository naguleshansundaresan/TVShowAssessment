<template>
  <div fluid class="mb-10">
    <v-img src="@/assets/tv-maze-background.jpg" height="350"></v-img>
    <v-container fluid>
      <h2 class="mt-6 mb-6 grey--text">
        TVmaze is a community of TV lovers and dedicated contributors that
        discuss and help maintain tv information on the web. Find episode
        information for any show on any device, anytime, anywhere! With TVmaze
        you can track your favorite shows from your desktop or laptop. From a
        browser or Windows.
      </h2>

      <hr class="blue darken-4" />
      <v-row>
        <h1 class="grey--text mx-6 my-8">Features</h1>
      </v-row>
      <v-row>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Show Information</h3>
            </v-card-title>
            <v-img src="../../src/assets/detail.png"></v-img>
            <v-card-text class="white--text"
              >Find Summaries, episode information, gallery, cast/crew/guest
              information of all shows.</v-card-text
            >
          </v-card>
        </v-col>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Episode lists</h3>
            </v-card-title>
            <v-img src="../../src/assets/episode-detail.png"></v-img>
            <v-card-text class="white--text"
              >A list of the episode numbering, episode name, rating and whether
              you've watched the episode.</v-card-text
            >
          </v-card>
        </v-col>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Favourites</h3>
            </v-card-title>
            <v-img src="../../src/assets/favourites.png"></v-img>
            <v-card-text class="white--text"
              >Monitor your favorite shows and follow the episodes</v-card-text
            >
          </v-card>
        </v-col>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Genre</h3>
            </v-card-title>
            <v-img src="../../src/assets/show-by-genre.png"></v-img>
            <v-card-text class="white--text"
              >Find related shows and episodes by selecting genre.</v-card-text
            >
          </v-card>
        </v-col>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Popular Shows</h3>
            </v-card-title>
            <v-img src="../../src/assets/popular.png"></v-img>
            <v-card-text class="white--text"
              >List of popular shows in market.</v-card-text
            >
          </v-card>
        </v-col>
        <v-col cols="6">
          <v-card
            class="grey--text"
            elevation="15"
            style="background-color: #0c2c57;"
          >
            <v-card-title>
              <h3>Search</h3>
            </v-card-title>
            <v-img src="../../src/assets/search.png"></v-img>
            <v-card-text class="white--text"
              >Find the details of the entire show by show name.</v-card-text
            >
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>
