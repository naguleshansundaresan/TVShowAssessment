<template>
  <div fluid>
    <v-tabs>
      <v-tab>Home</v-tab>
      <v-tab-item class="custom-style">
        <TvShowHomeDetail :key="tvShowInfo.id"></TvShowHomeDetail>
      </v-tab-item>
      <v-tab>Episodes</v-tab>
      <v-tab-item class="custom-style">
        <TvShowSeasons :showSeasons="tvShowSeasons"></TvShowSeasons>
      </v-tab-item>
      <v-tab>Cast</v-tab>
      <v-tab-item class="custom-style">
        <TvShowCast :showCast="tvShowCast"></TvShowCast>
      </v-tab-item>
      <v-tab>Crew</v-tab>
      <v-tab-item class="custom-style">
        <TvShowCrew :showCrew="tvShowCrew"></TvShowCrew>
      </v-tab-item>
      <v-tab>Gallery</v-tab>
      <v-tab-item class="custom-style">
        <TvShowGallery :showGallery="tvShowGallery"></TvShowGallery>
      </v-tab-item>
    </v-tabs>
  </div>
</template>

<script>
import { getShowInfo } from "@/services/show.service.js";
import TvShowHomeDetail from "@/components/tv-detail-components/TvShowHomeDetail.vue";
import TvShowSeasons from "@/components/tv-detail-components/TvShowSeasons.vue";
import TvShowCast from "@/components/tv-detail-components/TvShowCast.vue";
import TvShowCrew from "@/components/tv-detail-components/TvShowCrew.vue";
import TvShowGallery from "@/components/tv-detail-components/TvShowGallery.vue";
export default {
  name: "TvShowDetail",
  components: {
    TvShowHomeDetail,
    TvShowSeasons,
    TvShowCast,
    TvShowCrew,
    TvShowGallery
  },
  data() {
    return {
      tvShowId: this.$store.getters.getTvShowId,
      tvShowInfo: {},
      tvShowCast: [],
      tvShowCrew: [],
      tvShowSeasons: [],
      tvShowGallery: []
    };
  },
  methods: {
    async getTvShowInfo() {
      await getShowInfo(this.tvShowId)
        .then(response => {
          this.tvShowInfo = response.data;
          this.seggregateInfo();
        })
        .catch();
    },
    seggregateInfo() {
      this.$store.dispatch("setTvShowInfo", this.tvShowInfo);
      this.tvShowCast = this.tvShowInfo._embedded.cast;
      this.tvShowCrew = this.tvShowInfo._embedded.crew;
      this.tvShowSeasons = this.tvShowInfo._embedded.seasons;
      this.tvShowGallery = this.tvShowInfo._embedded.images;
    }
  },
  created() {
    this.getTvShowInfo();
  }
};
</script>

<style scoped>
.custom-style {
  background-color: #09203f;
  color: black;
  font-size: 18px;
}
</style>
