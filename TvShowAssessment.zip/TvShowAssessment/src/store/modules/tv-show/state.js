const state = {
  tvShowId: Number,
  favouriteList: [],
  tvShowInfo: {}
};

export default state;
