const actions = {
  setTvShowId(context, data) {
    context.commit("setTvShowId", data);
  },
  setTvShowInfo(context, data) {
    context.commit("setTvShowInfo", data);
  },
  addToFavouriteList(context, data) {
    let list = context.state.favouriteList;
    let update = true;
    list.forEach(show => {
      if (show.id === data.id) update = false;
    });
    if (update) list.push(data);
    context.commit("setFavouriteList", list);
  },
  removeFromFavouriteList(context, data) {
    let list = context.state.favouriteList;
    list.forEach(show => {
      if (show.id === data.id) {
        list.splice(list.indexOf(data), 1);
      }
    });
    context.commit("setFavouriteList", list);
  }
};

export default actions;
