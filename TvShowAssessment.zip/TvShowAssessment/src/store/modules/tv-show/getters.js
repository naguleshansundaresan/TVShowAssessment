const getters = {
  getTvShowId: state => state.tvShowId,
  getFavouriteList: state => state.favouriteList,
  getTvShowInfo: state => state.tvShowInfo
};

export default getters;
