const mutations = {
  setTvShowId: (state, showId) => {
    state.tvShowId = showId;
  },
  setFavouriteList: (state, data) => {
    state.favouriteList = data;
  },
  setTvShowInfo: (state, data) => {
    state.tvShowInfo = data;
  }
};

export default mutations;
