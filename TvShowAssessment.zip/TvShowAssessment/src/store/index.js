import Vue from "vue";
import Vuex from "vuex";
import mutations from "@/store/modules/tv-show/mutations.js";
import getters from "@/store/modules/tv-show/getters.js";
import actions from "@/store/modules/tv-show/actions.js";
import state from "@/store/modules/tv-show/state.js";
Vue.use(Vuex);

export default new Vuex.Store({
  state,
  mutations,
  getters,
  actions
});
