<template>
  <v-app style="background-color:  #09203f;">
    <AppHeader></AppHeader>
    <v-content>
      <router-view />
    </v-content>
    <hr class="blue darken-4" />
    <footer>
      <AppFooter></AppFooter>
    </footer>
  </v-app>
</template>

<script>
import AppHeader from "@/components/header/Header.vue";
import AppFooter from "@/components/footer/Footer.vue";
export default {
  name: "App",
  components: {
    AppHeader,
    AppFooter
  }
};
</script>
