import axios from "axios";

export const getShowsByName = showName => {
  return axios.get(`http://api.tvmaze.com/search/shows?q=${showName}`);
};

export const getAllShows = () => {
  return axios.get("http://api.tvmaze.com/shows");
};

export const getShowInfo = showId => {
  return axios.get(
    `http://api.tvmaze.com/shows/${showId}?embed[]=seasons&embed[]=cast&embed[]=crew&embed[]=images`
  );
};

export const getEpisodesInfo = season => {
  return axios.get(`http://api.tvmaze.com/seasons/${season}/episodes`);
};
