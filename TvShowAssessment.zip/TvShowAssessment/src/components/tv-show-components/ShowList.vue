<template>
  <v-container fluid>
    <v-row class="mx-2 mt-6 mb-3">
      <v-flex md9>
        <h2 class="mt-7">Shows</h2>
      </v-flex>
      <v-flex md3>
        <v-select
          :items="genres"
          v-model="selectedGenre"
          placeholder="Select By Genre"
          background-color="grey"
          class="mt-7"
          color="indigo"
          dense
          outlined
        ></v-select>
      </v-flex>
    </v-row>
    <v-row>
      <v-flex
        md3
        v-for="(show, index) in currentTvShowList"
        :key="index"
        class="pa-5"
      >
        <ShowCard :show="show"></ShowCard>
      </v-flex>
    </v-row>
  </v-container>
</template>

<script>
import ShowCard from "../tv-show-components/ShowCard.vue";
export default {
  name: "ShowList",
  components: {
    ShowCard
  },
  data() {
    return {
      currentTvShowList: [],
      selectedGenre: "",
      genres: [
        "Action",
        "Adventure",
        "Comedy",
        "Crime",
        "Drama",
        "Family",
        "History",
        "Horror",
        "Romance",
        "Science-Fiction",
        "Thriller"
      ]
    };
  },
  props: {
    tvShowList: Array
  },
  methods: {
    selectShowsByGenre() {
      this.currentTvShowList = [];
      this.tvShowList.forEach(show => {
        if (show.genres.includes(this.selectedGenre)) {
          this.currentTvShowList.push(show);
        }
      });
      this.currentTvShowList = this.currentTvShowList.slice(0, 24);
    }
  },
  watch: {
    selectedGenre() {
      return this.selectShowsByGenre();
    }
  }
};
</script>
