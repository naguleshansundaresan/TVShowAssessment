<template>
  <div>
    <v-card height="250" color="#09203f" flat fluid>
      <v-slide-group
        fluid
        v-model="model"
        dark
        class="slide-style"
        :contain="true"
        prev-icon="mdi-chevron-left"
        next-icon="mdi-chevron-right"
      >
        <v-slide-item
          v-for="(show, index) in showList"
          :key="index"
          class="slide-style"
        >
          <ShowCard :show="show"></ShowCard>
        </v-slide-item>
      </v-slide-group>
    </v-card>
  </div>
</template>

<script>
import ShowCard from "../tv-show-components/ShowCard.vue";
export default {
  name: "CardSlides",
  components: {
    ShowCard
  },
  data() {
    return {
      model: null
    };
  },
  props: {
    showList: Array
  }
};
</script>

<style>
.slide-style {
  background-color: #0c2c57;
  color: #09203f;
  font-size: 15px;
}
</style>
