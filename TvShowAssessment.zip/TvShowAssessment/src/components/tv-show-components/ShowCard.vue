<template>
  <v-card
    @mouseleave="hover = false"
    @mouseover="hover = true"
    v-model="hover"
    :elevation="hover ? 24 : 2"
    height="250"
    width="250"
    class="px-2"
    :color="hover ? '#091A3B' : '#0c2c57'"
  >
    <v-img
      :src="show.image.medium"
      :contain="true"
      height="210"
      width="250"
      v-if="show.image"
      @click="setTvShowId(show.id)"
    ></v-img>
    <v-img
      v-else
      src="@/assets/no-image-available.png"
      :contain="true"
      height="210"
      width="250"
      @click="setTvShowId(show.id)"
    ></v-img>
    <v-card-actions>
      <span class="yellow--text" v-if="show.rating">
        <v-icon dense color="yellow accent-4" class="ml-11 mb-1 mr-1"
          >mdi-star</v-icon
        >
        <span v-if="show.rating.average">{{ show.rating.average }}</span>
        <span v-else>N/A</span>
      </span>
      <v-btn
        icon
        color="red"
        class="ml-12 mr-1"
        v-model="fav"
        v-if="fav"
        @click="removeFromFavouriteList"
      >
        <v-icon color="red">mdi-heart</v-icon>
      </v-btn>

      <v-btn
        icon
        v-if="!fav"
        class="ml-12 mr-1"
        color="red"
        v-model="fav"
        @click="updateFavouriteList"
      >
        <v-icon>mdi-heart-outline</v-icon>
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "ShowCard",
  components: {},
  props: {
    show: Object
  },
  data() {
    return {
      hover: false,
      fav: false,
      tvShowFavouriteList: this.$store.getters.getFavouriteList
    };
  },
  methods: {
    setTvShowId(showId) {
      this.$store.dispatch("setTvShowId", showId);
      this.$router.push("detail");
    },
    updateFavouriteList() {
      this.fav = true;
      this.$store.dispatch("addToFavouriteList", this.show);
    },
    checkFavourite() {
      this.tvShowFavouriteList.forEach(show => {
        if (show.id === this.show.id) {
          this.fav = true;
        }
      });
    },
    removeFromFavouriteList() {
      this.fav = false;
      this.$store.dispatch("removeFromFavouriteList", this.show);
    }
  },
  created() {
    this.checkFavourite();
  }
};
</script>
