<template>
  <v-app-bar
    app
    style="background-color: #537895;background-image: linear-gradient(315deg, #537895 0%, #09203f 74%);"
  >
    <v-app-bar-nav-icon
      class="white--text"
      @click.stop="sidebar = !sidebar"
    ></v-app-bar-nav-icon>
    <span>
      <router-link to="/" style="text-decoration: none">
        <h2 class="white--text">TVMaze</h2>
      </router-link>
    </span>
    <v-spacer></v-spacer>
    <v-navigation-drawer
      v-model="sidebar"
      app
      absolute
      temporary
      class="white--text"
      style="background-color:  #09203f;"
    >
      <v-list>
        <v-list-item
          v-for="item in menuItems"
          :key="item.title"
          :to="item.path"
          class="white--text"
          style="background-color:  #09203f;"
        >
          <v-icon>{{ item.icon }}</v-icon>
          <v-list-item-title class="mx-1">{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>
  </v-app-bar>
</template>

<script>
export default {
  name: "AppHeader",
  data() {
    return {
      sidebar: false,
      menuItems: [
        { title: "Dashboard", path: "/", icon: "mdi-home" },
        { title: "Search", path: "/search", icon: "mdi-home-search" },
        { title: "Favourite", path: "/favourites", icon: "mdi-heart" },
        { title: "About", path: "/about", icon: "mdi-information" }
      ]
    };
  }
};
</script>
