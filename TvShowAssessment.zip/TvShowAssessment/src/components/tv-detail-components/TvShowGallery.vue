<template>
  <v-container grid-list-xl>
    <v-row>
      <v-flex v-for="(image, index) in showGallery" :key="index">
        <v-card flat outlined class="ma-2" width="250">
          <v-img
            :src="image.resolutions.original.url"
            width="250"
            max-height="300"
            v-if="image.resolutions"
          ></v-img>
        </v-card>
      </v-flex>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "TvShowGallery",
  props: {
    showGallery: Array
  }
};
</script>
