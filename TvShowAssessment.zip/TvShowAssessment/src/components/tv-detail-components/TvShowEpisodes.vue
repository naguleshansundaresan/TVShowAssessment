<template>
  <v-container class="mt-5" grid-list-xl>
    <v-row>
      <v-flex v-for="(episode, index) in episodeList" :key="index">
        <v-card
          class="custom-style pb-5"
          outlined
          raised
          elevation="15px"
          fluid
          :href="episode.url"
          target="_blank"
        >
          <v-row class="custom-style">
            <v-flex md4>
              <v-img
                :src="episode.image.medium"
                height="250"
                width="250"
                v-if="episode.image"
              ></v-img>
            </v-flex>
            <v-flex md8>
              <v-card-title>{{ episode.name }}</v-card-title>
              <v-card-subtitle class="white--text">
                <strong
                  >Episode {{ episode.season }} * {{ episode.number }}</strong
                >
              </v-card-subtitle>
              <v-card-text style="font-size: 18px" v-html="episode.summary">
                <span class="custom-style"
                  >Airdate : {{ episode.airdate }}</span
                >
              </v-card-text>
            </v-flex>
          </v-row>
        </v-card>
      </v-flex>
    </v-row>
  </v-container>
</template>

<script>
import { getEpisodesInfo } from "@/services/show.service.js";
export default {
  name: "TvShowEpisodes",
  props: {
    season: Number
  },
  data() {
    return {
      episodeList: []
    };
  },
  methods: {
    async getEpisodes() {
      await getEpisodesInfo(this.$props.season).then(response => {
        this.episodeList = response.data;
      });
    }
  },
  created() {
    this.getEpisodes();
  }
};
</script>

<style scoped>
.custom-style {
  background-color: #09203f;
  color: white;
  font-size: 18px;
  border-style: inset;
}
</style>
