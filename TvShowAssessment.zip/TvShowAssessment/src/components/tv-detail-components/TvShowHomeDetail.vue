<template>
  <div class="card-style ma-6 mb-10">
    <v-card class="card-style ma-6" max-width="1200" flat>
      <v-row>
        <v-flex md4>
          <v-img
            class="card-style"
            :src="tvShowInfo.image.original"
            :contain="true"
            max-width="600"
            max-height="600"
            v-if="tvShowInfo.image"
          ></v-img>
          <v-img
            v-else
            src="@/assets/no-image-available.png"
            height="400"
            width="400"
          ></v-img>
        </v-flex>

        <v-flex md8>
          <v-card class="card-style ma-6 ml-10" flat>
            <v-row justify="center">
              <v-card-title v-if="tvShowInfo.name != null">
                <h1>{{ tvShowInfo.name }}</h1>
              </v-card-title>
            </v-row>
            <v-card-text>
              <v-row align="center">
                <span
                  class="white--text px-3 py-1"
                  v-if="tvShowInfo.summary"
                  v-html="tvShowInfo.summary"
                ></span>
              </v-row>
              <v-row align="center">
                <v-col cols="6">
                  <b class="white--text mr-2">Rating : </b>
                  <span v-if="tvShowInfo.rating">
                    <v-progress-circular
                      color="red"
                      :value="tvShowInfo.rating.average * 10"
                      >{{ tvShowInfo.rating.average }}</v-progress-circular
                    >
                  </span>
                  <span v-else class="white--text  mr-2">N/A</span>
                </v-col>
                <v-col cols="6">
                  <span class="white--text mr-2" v-if="tvShowInfo.language">
                    <b class="mr-2">Language : </b>
                    {{ tvShowInfo.language }}
                  </span>
                </v-col>
              </v-row>
              <v-row align="center">
                <v-col cols="6">
                  <span class="white--text" v-if="tvShowInfo.status">
                    <b class="mr-2">Status : </b>
                    {{ tvShowInfo.status }}
                  </span>
                </v-col>
                <v-col cols="6">
                  <span class="white--text mr-2" v-if="tvShowInfo.premiered">
                    <b class="mr-2">Premiered on : </b>
                    {{ tvShowInfo.premiered }}
                  </span>
                </v-col>
              </v-row>
              <v-row align="center">
                <v-col cols="6">
                  <span class="white--text mr-2" v-if="tvShowInfo.schedule">
                    <b class="mr-2">Schedule :</b>
                    {{ tvShowInfo.schedule.days[0] }} at
                    {{ tvShowInfo.schedule.time }}
                  </span>
                </v-col>
                <v-col cols="6">
                  <span class="white--text mr-2" v-if="tvShowInfo.type">
                    <b class="mr-2">Type :</b>
                    {{ tvShowInfo.type }}
                  </span>
                </v-col>
              </v-row>
              <v-row>
                <span
                  class="white--text px-3 py-2"
                  v-if="tvShowInfo.officialSite"
                >
                  <b class="mr-2">Official Site : </b>
                  <a :href="tvShowInfo.officialSite">{{
                    tvShowInfo.officialSite
                  }}</a>
                </span>
              </v-row>

              <v-row>
                <div v-if="tvShowInfo.genres" class="white--text pa-2 pl-3">
                  <b class="mr-2">Genre : </b>
                  <span v-for="showGenre in tvShowInfo.genres" :key="showGenre">
                    <v-icon color="indigo" left>mdi-tag</v-icon>
                    {{ showGenre }}
                  </span>
                </div>
              </v-row>
              <v-row>
                <div class="white--text ma-3">
                  <span>
                    <b class="mr-2">Add To Favourites</b>
                  </span>
                  <v-btn
                    icon
                    color="red"
                    class="ml-3 mr-3"
                    v-model="fav"
                    v-if="fav"
                    @click="removeFromFavouriteList"
                  >
                    <v-icon color="red">mdi-heart</v-icon>
                  </v-btn>

                  <v-btn
                    icon
                    v-if="!fav"
                    class="ml-3 mr-3"
                    color="red"
                    v-model="fav"
                    @click="updateFavouriteList"
                  >
                    <v-icon>mdi-heart-outline</v-icon>
                  </v-btn>
                </div>
              </v-row>
            </v-card-text>
          </v-card>
        </v-flex>
      </v-row>
    </v-card>
  </div>
</template>

<script>
export default {
  name: "TvShowHomeDetail",
  data() {
    return {
      tvShowInfo: this.$store.getters.getTvShowInfo,
      fav: false,
      tvShowFavouriteList: this.$store.getters.getFavouriteList
    };
  },
  methods: {
    updateFavouriteList() {
      this.fav = true;
      this.$store.dispatch("addToFavouriteList", this.tvShowInfo);
    },
    checkFavourite() {
      this.tvShowFavouriteList.forEach(show => {
        if (show.id === this.tvShowInfo.id) {
          this.fav = true;
        }
      });
    },
    removeFromFavouriteList() {
      this.fav = false;
      this.$store.dispatch("removeFromFavouriteList", this.tvShowInfo);
    }
  },
  created() {
    this.checkFavourite();
  }
};
</script>

<style scoped>
.card-style {
  background-color: #09203f;
  color: white;
  font-size: 18px;
  padding: 5px 5px 5px 3px;
}
.text-style {
  font-size: 18px;
  padding: 5px 5px 5px 3px;
  color: white;
}
</style>
