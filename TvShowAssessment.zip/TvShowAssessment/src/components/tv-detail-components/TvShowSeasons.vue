<template>
  <div class="card-style">
    <v-card height="250" color="#09203f" flat fluid>
      <v-slide-group
        dark
        fluid
        class="slide-style"
        :contain="true"
        prev-icon="mdi-chevron-left"
        next-icon="mdi-chevron-right"
      >
        <v-slide-item v-for="(season, index) in showSeasons" :key="index">
          <v-hover v-slot:default="{ hover }">
            <v-card
              class="px-2"
              :elevation="hover ? 24 : 2"
              height="250"
              width="250"
              :color="hover ? '#091A3B' : '#0c2c57'"
              @click="updateSeason(season.id)"
            >
              <v-img
                :src="season.image.medium"
                :contain="true"
                width="250"
                v-if="season.image"
              >
                <v-expand-transition>
                  <div
                    v-if="hover"
                    class="transition-fast-in-fast-out display-2 white--text expand-style"
                    style="height: 100%;background-color: #FAB859"
                  >
                    <span class="pt-10">Season {{ season.number }}</span>
                  </div>
                </v-expand-transition>
              </v-img>
              <v-img
                v-else
                src="@/assets/no-image-available.png"
                :contain="true"
                height="200"
                width="200"
              >
                <v-expand-transition>
                  <div
                    v-if="hover"
                    class="transition-fast-in-fast-out v-card--reveal display-2 white--text expand-style"
                    style="height: 100%;background-color: #FAB859"
                  >
                    <span class="pt-10">Season {{ season.number }}</span>
                  </div>
                </v-expand-transition>
              </v-img>
            </v-card>
          </v-hover>
        </v-slide-item>
      </v-slide-group>
    </v-card>
    <h3 class="white--text mt-10 mx-8">Episodes</h3>
    <span v-if="currentSeason > 0">
      <TvShowEpisodes
        :season="currentSeason"
        :key="currentSeason"
      ></TvShowEpisodes>
    </span>
  </div>
</template>

<script>
import TvShowEpisodes from "../tv-detail-components/TvShowEpisodes.vue";
export default {
  name: "TvShowSeasons",
  components: {
    TvShowEpisodes
  },
  data() {
    return {
      currentSeason: Number
    };
  },
  props: {
    showSeasons: Array
  },
  methods: {
    updateSeason(season) {
      this.currentSeason = season;
    }
  }
};
</script>

<style scoped>
.card-style {
  background-color: #09203f;
  color: black;
  font-size: 18px;
}
</style>
