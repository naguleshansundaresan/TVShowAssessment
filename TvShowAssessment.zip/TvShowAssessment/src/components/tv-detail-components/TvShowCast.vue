<template>
  <v-container grid-list-xl>
    <v-row class="white--text mt-3 mx-2">
      <h2>Cast</h2>
    </v-row>
    <v-row>
      <v-flex md3 v-for="(cast, index) in showCast" :key="index" class="pa-5">
        <v-card
          elevation="15"
          outlined
          :href="cast.person.url"
          target="_blank"
          v-if="cast.person.url"
          width="220"
        >
          <v-img
            height="200"
            width="220"
            :src="cast.person.image.medium"
            v-if="cast.person.image"
          ></v-img>
          <v-img
            v-else
            height="200"
            width="220"
            src="@/assets/no-image-available.png"
          ></v-img>
          <v-card-text align="center">
            <span v-if="cast.person.name">
              <b>{{ cast.person.name }}</b>
            </span>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "TvShowCast",
  props: {
    showCast: Array
  }
};
</script>
