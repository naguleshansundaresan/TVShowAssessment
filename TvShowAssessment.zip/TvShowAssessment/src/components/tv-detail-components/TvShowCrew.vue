<template>
  <v-container grid-list-xl>
    <v-row class="white--text mt-3 mx-2">
      <h2>Crew</h2>
    </v-row>
    <v-row>
      <v-flex md3 v-for="(crew, index) in showCrew" :key="index" class="pa-5">
        <v-card
          elevation="15"
          outlined
          :href="crew.person.url"
          target="_blank"
          v-if="crew.person.url"
          width="220"
        >
          <v-img
            height="200"
            width="220"
            :src="crew.person.image.medium"
            v-if="crew.person.image"
          ></v-img>
          <v-img
            v-else
            height="200"
            width="220"
            src="@/assets/no-image-available.png"
          ></v-img>
          <v-card-text>
            <v-row justify="center" v-if="crew.person.name">
              <h4>{{ crew.person.name }}</h4>
            </v-row>
            <v-row justify="center" v-if="crew.type">
              <h5>{{ crew.type }}</h5>
            </v-row>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "TvShowCrew",
  props: {
    showCrew: Array
  }
};
</script>
