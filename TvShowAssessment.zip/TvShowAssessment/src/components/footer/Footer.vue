<template>
  <v-footer style="background-color: #09203f;color: white;">
    <v-col class="white--text" cols="12" align="center">
      Copyright &copy; 2020, TvMaze. All Rights Reserved.
    </v-col>
  </v-footer>
</template>

<script>
export default {
  name: "AppFooter"
};
</script>
