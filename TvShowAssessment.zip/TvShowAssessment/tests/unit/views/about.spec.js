import { shallowMount } from "@vue/test-utils";
import About from "@/views/About.vue";
import Vuetify from "vuetify";
import Vue from "vue";

describe("In App Component", () => {
  let aboutWrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    aboutWrapper = shallowMount(About, {
      Vue
    });
  });
  afterEach(() => {
    aboutWrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(aboutWrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a v-container", () => {
    expect(aboutWrapper.html()).toContain("v-container");
  });

  it("it should have a v-content", () => {
    expect(aboutWrapper.html()).toContain("v-card");
  });
});
