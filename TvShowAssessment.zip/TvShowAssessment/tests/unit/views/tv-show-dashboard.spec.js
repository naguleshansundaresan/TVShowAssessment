import { shallowMount } from "@vue/test-utils";
import TvShowDashboard from "@/views/TvShowDashboard.vue";
import Vuetify from "vuetify";
import Vue from "vue";
import Vuex from "vuex";
import { tvAllShowMockData } from "./tv-show-data.fixture.js";
import CardSlides from "@/components/tv-show-components/CardSlides.vue";
import ShowList from "@/components/tv-show-components/ShowList.vue";
import { routes } from "@/router/index";
import VueRouter from "vue-router";
describe("From TvShowSearch Component ", () => {
  let wrapper;
  let router = new VueRouter({ routes });
  let actions = {
    setTvShowId: jest.fn()
  };
  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(Vuex);
    Vue.use(VueRouter);
    let store = new Vuex.Store({
      actions
    });
    wrapper = shallowMount(TvShowDashboard, {
      Vue,
      store,
      router,
      data() {
        return {
          success: false,
          popularShowsList: [],
          tvShowsDashboardList: tvAllShowMockData
        };
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(wrapper.html()).toContain("v-container-stub");
  });

  it("should find v-img", () => {
    expect(wrapper.html()).toContain("v-img-stub");
  });

  it("it should load the card-slides", () => {
    expect(CardSlides).toBeTruthy();
  });

  it("it should load the show-list", () => {
    expect(ShowList).toBeTruthy();
  });

  it("should find h3", () => {
    expect(wrapper.html()).toContain("h3");
  });

  it("should find span", () => {
    expect(wrapper.html()).toContain("span");
  });

  it("getAllTvShows function should be called on create", () => {
    const spyinit = jest.spyOn(wrapper.vm, "getAllTvShows");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
      expect(wrapper.vm.getTvShowsDashboardList).toHaveBeenCalled();
    });
  });

  it("getTvShowsDashboardList function should be called ", () => {
    const spyinit = jest.spyOn(wrapper.vm, "sortTvShow");
    wrapper.vm.getTvShowsDashboardList(tvAllShowMockData);
    expect(spyinit).toHaveBeenCalled();
  });

  it("sortTvShow function should be tested", () => {
    wrapper.vm.tvShowsDashboardList = [
      { name: "Breaking Bad", rating: { average: 8 } },
      { name: "GOT", rating: { average: 9 } }
    ];
    let expected = [
      { name: "GOT", rating: { average: 9 } },
      { name: "Breaking Bad", rating: { average: 8 } }
    ];
    wrapper.vm.sortTvShow();
    expect(wrapper.vm.tvShowsDashboardList).toEqual(expected);
  });
});
