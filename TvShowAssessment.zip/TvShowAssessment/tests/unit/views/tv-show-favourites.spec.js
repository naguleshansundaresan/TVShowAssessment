import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import Vuex from "vuex";
import { tvAllShowMockData } from "../views/tv-show-data.fixture.js";
import TvShowFavourites from "@/views/TvShowFavourites.vue";
describe("From TvShowFavourites Component ", () => {
  let wrapper;
  let getters = {
    getFavouriteList: () => tvAllShowMockData
  };
  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(Vuex);
    let store = new Vuex.Store({
      getters
    });
    wrapper = shallowMount(TvShowFavourites, {
      Vue,
      store,
      data() {
        return {
          dialog: false,
          tvShowFavouriteList: tvAllShowMockData
        };
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("getFavouriteShows function should be called on create", () => {
    wrapper.vm.tvShowFavouriteList = [];
    const spyinit = jest.spyOn(wrapper.vm, "getFavouriteShows");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
      expect(wrapper.vm.dialog).toBe(true);
    });
  });

  it("getFavouriteShows function should be called on create", () => {
    wrapper.vm.tvShowFavouriteList = tvAllShowMockData;
    const spyinit = jest.spyOn(wrapper.vm, "getFavouriteShows");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
      expect(wrapper.vm.dialog).toBe(false);
    });
  });
});
