import { shallowMount } from "@vue/test-utils";
import TvShowSearch from "@/views/TvShowSearch.vue";
import Vuetify from "vuetify";
import Vue from "vue";
import { tvMockSearchData } from "./tv-show-data.fixture.js";
import ShowCard from "@/components/tv-show-components/ShowCard.vue";
describe("From TvShowSearch Component ", () => {
  let tvShowSearchWrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    tvShowSearchWrapper = shallowMount(TvShowSearch, {
      Vue,
      data() {
        return {
          dialog: false,
          searchedTvShow: "breaking bad",
          tvShowSearchList: tvMockSearchData
        };
      }
    });
  });

  afterEach(() => {
    tvShowSearchWrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(tvShowSearchWrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-container-stub");
  });

  it("should find v-row", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-row-stub");
  });

  it("it should load the show-card", () => {
    expect(ShowCard).toBeTruthy();
  });

  it("should find v-text-field-stub", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-text-field-stub");
  });

  it("should find v-flex", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-flex-stub");
  });

  it("should find v-btn", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-btn-stub");
  });

  it("should find v-icon-stub", () => {
    expect(tvShowSearchWrapper.html()).toContain("v-icon-stub");
  });

  it("getSearchedTvShow function should be tested", () => {
    tvShowSearchWrapper.vm.getSearchedTvShow();
    expect(tvShowSearchWrapper.vm.dialog).toBe(false);
  });

  it("checkDialog function should be tested", () => {
    tvShowSearchWrapper.vm.tvShowSearchList = [];
    tvShowSearchWrapper.vm.checkDialog();
    expect(tvShowSearchWrapper.vm.dialog).toBe(true);
  });

  it("testing tv-showsearch without list data", () => {
    Vue.use(Vuetify);
    tvShowSearchWrapper = shallowMount(TvShowSearch, {
      Vue,
      data() {
        return {
          dialog: true,
          searchedTvShow: "breaking bad",
          tvShowSearchList: []
        };
      }
    });
  });
});
