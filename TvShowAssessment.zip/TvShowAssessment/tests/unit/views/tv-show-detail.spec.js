import TvShowHomeDetail from "@/components/tv-detail-components/TvShowHomeDetail.vue";
import TvShowSeasons from "@/components/tv-detail-components/TvShowSeasons.vue";
import TvShowCast from "@/components/tv-detail-components/TvShowCast.vue";
import TvShowCrew from "@/components/tv-detail-components/TvShowCrew.vue";
import TvShowGallery from "@/components/tv-detail-components/TvShowGallery.vue";
import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import Vuex from "vuex";
import TvShowDetail from "@/views/TvShowDetail.vue";

describe("From TvShowFavourites Component ", () => {
  let wrapper;
  let getters = {
    getTvShowId: () => 169
  };
  let actions = {
    setTvShowInfo: jest.fn()
  };
  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(Vuex);
    let store = new Vuex.Store({
      getters,
      actions
    });
    wrapper = shallowMount(TvShowDetail, {
      Vue,
      store,
      data() {
        return {
          tvShowId: 169,
          tvShowInfo: {
            name: "breaking bad",
            _embedded: {
              cast: ["Mike", "Ike"],
              crew: ["Producer", "Director"],
              seasons: [1, 2, 3],
              images: ["1.png", "2.png"]
            }
          },
          tvShowCast: [],
          tvShowCrew: [],
          tvShowSeasons: [],
          tvShowGallery: []
        };
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("should find div", () => {
    expect(wrapper.html()).toContain("div");
  });

  it("should find v-tabs", () => {
    expect(wrapper.html()).toContain("v-tabs-stub");
  });

  it("should find v-tabs-stub", () => {
    expect(wrapper.html()).toContain("v-tabs-stub");
  });

  it("should find v-tab-item-stub", () => {
    expect(wrapper.html()).toContain("v-tab-item-stub");
  });

  it("it should load the tv-show-gallery", () => {
    expect(TvShowGallery).toBeTruthy();
  });

  it("it should load the tv-show-crew", () => {
    expect(TvShowCrew).toBeTruthy();
  });

  it("it should load the tv-show-cast", () => {
    expect(TvShowCast).toBeTruthy();
  });

  it("it should load the tv-show-seasons", () => {
    expect(TvShowSeasons).toBeTruthy();
  });

  it("it should load the tv-show-home-detail", () => {
    expect(TvShowHomeDetail).toBeTruthy();
  });

  it("seggregateShowInfo function should be tested", () => {
    wrapper.vm.seggregateInfo();
    let expected = ["Mike", "Ike"];
    expect(wrapper.vm.tvShowCast).toEqual(expected);
    expected = ["Producer", "Director"];
    expect(wrapper.vm.tvShowCrew).toEqual(expected);
    expected = [1, 2, 3];
    expect(wrapper.vm.tvShowSeasons).toEqual(expected);
    expected = ["1.png", "2.png"];
    expect(wrapper.vm.tvShowGallery).toEqual(expected);
  });

  it("getTvShowInfo function should be called on create", async () => {
    const spyinit = jest.spyOn(wrapper.vm, "getTvShowInfo");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
    });
  });
});
