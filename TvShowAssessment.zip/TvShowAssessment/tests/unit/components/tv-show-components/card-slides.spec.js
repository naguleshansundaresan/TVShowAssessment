import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import ShowCard from "@/components/tv-show-components/ShowCard.vue";
import CardSlides from "@/components/tv-show-components/CardSlides.vue";
import { tvAllShowMockData } from "../../views/tv-show-data.fixture.js";
describe("From CardSlides Component ", () => {
  let wrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    wrapper = shallowMount(CardSlides, {
      Vue,
      data() {
        return {
          model: null
        };
      },
      propsData: {
        showList: tvAllShowMockData
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-slide-group-stub>", () => {
    expect(wrapper.html()).toContain("v-slide-group-stub");
  });

  it("it should have a <v-slide-item-stub>", () => {
    expect(wrapper.html()).toContain("v-slide-item-stub");
  });

  it("should find v-card", () => {
    expect(wrapper.html()).toContain("v-card-stub");
  });

  it("it should load the show-card", () => {
    expect(ShowCard).toBeTruthy();
  });

  it("should find div", () => {
    expect(wrapper.html()).toContain("div");
  });
});
