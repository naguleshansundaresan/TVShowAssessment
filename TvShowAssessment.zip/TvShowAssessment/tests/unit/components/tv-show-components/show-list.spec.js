import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import { tvAllShowMockData } from "../../views/tv-show-data.fixture.js";
import ShowCard from "@/components/tv-show-components/ShowCard.vue";
import ShowList from "@/components/tv-show-components/ShowList.vue";
describe("From ShowList Component ", () => {
  let wrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    wrapper = shallowMount(ShowList, {
      Vue,
      data() {
        return {
          currentTvShowList: [],
          selectedGenre: "",
          genres: [
            "Action",
            "Adventure",
            "Comedy",
            "Crime",
            "Drama",
            "Family",
            "History",
            "Horror",
            "Romance",
            "Science-Fiction",
            "Thriller"
          ]
        };
      },
      propsData: {
        tvShowList: tvAllShowMockData
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(wrapper.html()).toContain("v-container-stub");
  });

  it("should find v-row", () => {
    expect(wrapper.html()).toContain("v-row-stub");
  });

  it("it should load the show-card", () => {
    expect(ShowCard).toBeTruthy();
  });

  it("should find v-flex", () => {
    expect(wrapper.html()).toContain("v-flex-stub");
  });

  it("should find v-select-stub", () => {
    expect(wrapper.html()).toContain("v-select-stub");
  });

  it("selectShowsByGenre function should be tested", () => {
    wrapper.vm.selectedGenre = "Crime";
    wrapper.vm.selectShowsByGenre();
    expect(wrapper.vm.currentTvShowList.length).toBe(5);
  });
});
