import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import TvShowGallery from "@/components/tv-detail-components/TvShowGallery.vue";
describe("From TvShowGallery Component ", () => {
  let wrapper;

  beforeEach(() => {
    Vue.use(Vuetify);
    wrapper = shallowMount(TvShowGallery, {
      Vue,
      propsData: {
        showGallery: [
          {
            id: 3601,
            resolutions: {
              original: {
                url:
                  "http://static.tvmaze.com/uploads/images/original_untouched/1/3603.jpg"
              },
              medium: {
                url:
                  "http://static.tvmaze.com/uploads/images/medium_portrait/1/3603.jpg"
              }
            }
          }
        ]
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(wrapper.html()).toContain("v-container-stub");
  });

  it("should find v-row", () => {
    expect(wrapper.html()).toContain("v-row-stub");
  });

  it("should find v-flex", () => {
    expect(wrapper.html()).toContain("v-flex-stub");
  });

  it("should find v-card-stub", () => {
    expect(wrapper.html()).toContain("v-card-stub");
  });
});
