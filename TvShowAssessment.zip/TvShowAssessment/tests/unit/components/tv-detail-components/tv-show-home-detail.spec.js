import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import Vuex from "vuex";
import { tvAllShowMockData } from "../../views/tv-show-data.fixture.js";
import TvShowHomeDetail from "@/components/tv-detail-components/TvShowHomeDetail.vue";
describe("From TvShowHomeDetail Component ", () => {
  let wrapper;
  let show = { id: 1, name: "Under the Dome" };
  let getters = {
    getTvShowInfo: jest.fn(),
    getFavouriteList: jest.fn()
  };
  let actions = {
    removeFromFavouriteList: jest.fn(),
    addToFavouriteList: jest.fn()
  };

  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(Vuex);
    let store = new Vuex.Store({
      getters,
      actions
    });
    wrapper = shallowMount(TvShowHomeDetail, {
      Vue,
      store,
      data() {
        return {
          tvShowInfo: show,
          fav: false,
          tvShowFavouriteList: tvAllShowMockData
        };
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("updateFavouriteList function should be tested", () => {
    wrapper.vm.updateFavouriteList();
    expect(wrapper.vm.fav).toBe(true);
  });

  it("checkFavourite function should be called on created hook", () => {
    const spyinit = jest.spyOn(wrapper.vm, "checkFavourite");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
      expect(wrapper.vm.fav).toBe(true);
    });
  });

  it("removeFromFavouriteList function should be tested", () => {
    wrapper.vm.removeFromFavouriteList();
    expect(wrapper.vm.fav).toBe(false);
  });
});
