import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import Vuex from "vuex";
import { tvAllShowMockData } from "../../views/tv-show-data.fixture.js";
import TvShowSeasons from "@/components/tv-detail-components/TvShowSeasons.vue";
import TvShowEpisodes from "@/components/tv-detail-components/TvShowEpisodes.vue";
describe("From ShowSeasons Component ", () => {
  let wrapper;
  let getters = {
    getFavouriteList: () => tvAllShowMockData
  };
  let actions = {
    removeFromFavouriteList: jest.fn(),
    addToFavouriteList: jest.fn(),
    setCurrentTvShow: jest.fn()
  };

  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(Vuex);
    let store = new Vuex.Store({
      getters,
      actions
    });
    wrapper = shallowMount(TvShowSeasons, {
      Vue,
      store,
      data() {
        return {
          currentSeason: 1
        };
      },
      props: {
        showSeasons: [
          { id: 1, number: 1, image: { medium: "1.png" } },
          { id: 2, number: 2, image: { medium: "2.png" } }
        ]
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("Loading TvShowEpisodes ", () => {
    expect(TvShowEpisodes).toBeTruthy();
  });

  it("updateSeason function should be tested", () => {
    wrapper.vm.updateSeason(1);
    expect(wrapper.vm.currentSeason).toEqual(1);
  });
});
