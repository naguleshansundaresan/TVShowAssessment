import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import TvShowCrew from "@/components/tv-detail-components/TvShowCrew.vue";
describe("From TvShowCrew Component ", () => {
  let wrapper;

  beforeEach(() => {
    Vue.use(Vuetify);
    wrapper = shallowMount(TvShowCrew, {
      Vue,
      propsData: {
        showCrew: [
          {
            person: {
              name: "Robert",
              url: "1.png",
              image: { medium: "2.png" }
            }
          }
        ]
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(wrapper.html()).toContain("v-container-stub");
  });

  it("should find v-row", () => {
    expect(wrapper.html()).toContain("v-row-stub");
  });

  it("should find v-flex", () => {
    expect(wrapper.html()).toContain("v-flex-stub");
  });

  it("should find v-img", () => {
    expect(wrapper.html()).toContain("v-img-stub");
  });

  it("should find v-card-stub", () => {
    expect(wrapper.html()).toContain("v-card-stub");
  });
});
