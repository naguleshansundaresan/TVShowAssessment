import { shallowMount } from "@vue/test-utils";
import Vuetify from "vuetify";
import Vue from "vue";
import TvShowEpisodes from "@/components/tv-detail-components/TvShowEpisodes.vue";
describe("From TvShowEpisodes Component ", () => {
  let wrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    wrapper = shallowMount(TvShowEpisodes, {
      Vue,
      propsData: {
        season: 1
      },
      data() {
        return {
          episodeList: [
            {
              name: "pilot",
              number: 1,
              url:
                "http://www.tvmaze.com/episodes/28/person-of-interest-1x01-pilot",
              airdate: "2011-09-22",
              image: {
                medium:
                  "http://static.tvmaze.com/uploads/images/medium_landscape/35/89344.jpg",
                original:
                  "http://static.tvmaze.com/uploads/images/original_untouched/35/89344.jpg"
              },
              summary:
                "<p>John Reese is a former CIA operative living off the grid in NYC.</p>"
            }
          ]
        };
      }
    });
  });

  afterEach(() => {
    wrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-container-stub>", () => {
    expect(wrapper.html()).toContain("v-container-stub");
  });

  it("should find v-row", () => {
    expect(wrapper.html()).toContain("v-row-stub");
  });

  it("should find v-flex", () => {
    expect(wrapper.html()).toContain("v-flex-stub");
  });

  it("should find span", () => {
    expect(wrapper.html()).toContain("span");
  });

  it("should find v-card-stub", () => {
    expect(wrapper.html()).toContain("v-card-stub");
  });

  it("getEpisodes function should be called on create", async () => {
    const spyinit = jest.spyOn(wrapper.vm, "getEpisodes");
    setTimeout(() => {
      expect(spyinit).toHaveBeenCalled();
    });
  });
});
