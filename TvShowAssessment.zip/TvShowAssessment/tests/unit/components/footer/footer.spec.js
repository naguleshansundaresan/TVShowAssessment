import { shallowMount } from "@vue/test-utils";
import Footer from "@/components/footer/Footer.vue";
import Vuetify from "vuetify";
import { routes } from "@/router/index";
import VueRouter from "vue-router";
import Vue from "vue";
describe("From Footer Component ", () => {
  let footerWrapper;
  const router = new VueRouter({ routes });
  beforeEach(() => {
    Vue.use(Vuetify);
    footerWrapper = shallowMount(Footer, {
      Vue,
      router,
      attachToDocument: true
    });
  });
  afterEach(() => {
    footerWrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(footerWrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a <v-footer-stub>", () => {
    expect(footerWrapper.html()).toContain("v-footer-stub");
  });

  it("should find v-col", () => {
    expect(footerWrapper.html()).toContain("v-col-stub");
  });
});
