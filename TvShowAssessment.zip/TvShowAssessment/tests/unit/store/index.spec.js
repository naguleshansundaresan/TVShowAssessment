import store from "../../../src/store";
describe("In Store", () => {
  it("it should be truthy ", () => {
    expect(store).toBeTruthy();
  });
});
