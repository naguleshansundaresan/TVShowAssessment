import actions from "@/store/modules/tv-show/actions.js";
import mutations from "@/store/modules/tv-show/mutations.js";
import getters from "@/store/modules/tv-show/getters.js";
describe("In Actions ", () => {
  let context;
  const commit = jest.fn();
  let tvShowId = 1;
  let currentTvShow = { name: "test1", id: 1 };
  let tvShowInfo = { name: "test1" };
  const state = {
    tvShowId: 1,
    currentTvShow: { name: "testName1", id: 1 },
    favouriteList: [
      { name: "testName1", id: 1 },
      { name: "testName", id: 2 }
    ],
    tvShowInfo: { name: "test1" }
  };
  beforeEach(() => {
    context = {
      state,
      getters,
      mutations,
      commit
    };
  });

  it("Testing setTvShowId action ", () => {
    actions.setTvShowId(context, tvShowId);
    expect(state.tvShowId).toBe(tvShowId);
  });

  it("Testing addToFavouriteList action ", () => {
    actions.addToFavouriteList(context, currentTvShow);
  });

  it("Testing removeFromFavouriteList action ", () => {
    actions.removeFromFavouriteList(context, currentTvShow);
  });

  it("Testing addToFavouriteList action ", () => {
    currentTvShow = { name: "Bre", id: 3 };
    actions.addToFavouriteList(context, currentTvShow);
  });

  it("Testing setTvShowInfo action ", () => {
    actions.setTvShowInfo(context, tvShowInfo);
    expect(state.tvShowInfo).toEqual(tvShowInfo);
  });
});
