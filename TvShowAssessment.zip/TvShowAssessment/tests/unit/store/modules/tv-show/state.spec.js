import state from "@/store/modules/tv-show/state.js";
describe("In State", () => {
  it("it should have all state objects ", () => {
    expect(state).toBeTruthy();
  });
});
