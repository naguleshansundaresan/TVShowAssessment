import getters from "@/store/modules/tv-show/getters.js";
describe("In Getters ", () => {
  it("Testing getters ", () => {
    const tvShowId = 1;
    const favouriteList = [{ name: "testName1" }, { name: "testName" }];
    const tvShowInfo = { name: "test1" };
    const state = {
      tvShowId: 1,
      currentTvShow: { name: "test1" },
      favouriteList: [{ name: "testName1" }, { name: "testName" }],
      tvShowInfo: { name: "test1" }
    };
    getters.getTvShowId(state);
    expect(state.tvShowId).toBe(tvShowId);

    getters.getFavouriteList(state);
    expect(state.favouriteList).toEqual(favouriteList);

    getters.getTvShowInfo(state);
    expect(state.tvShowInfo).toEqual(tvShowInfo);
  });
});
