import mutations from "@/store/modules/tv-show/mutations.js";
describe("In Mutations ", () => {
  it("Testing mutations ", () => {
    const tvShowId = 1;
    const favouriteList = [{ name: "testName1" }, { name: "testName" }];
    const tvShowInfo = { name: "test1" };
    const state = {
      tvShowId: 0,
      currentTvShow: {},
      favouriteList: [],
      tvShowInfo: []
    };
    mutations.setTvShowId(state, tvShowId);
    expect(state.tvShowId).toBe(tvShowId);

    mutations.setFavouriteList(state, favouriteList);
    expect(state.favouriteList).toBe(favouriteList);

    mutations.setTvShowInfo(state, tvShowInfo);
    expect(state.tvShowInfo).toBe(tvShowInfo);
  });
});
