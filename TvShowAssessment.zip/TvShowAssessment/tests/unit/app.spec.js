import { shallowMount } from "@vue/test-utils";
import App from "@/App.vue";
import Vuetify from "vuetify";
import Vue from "vue";
import Header from "@/components/header/Header.vue";
import VueRouter from "vue-router";
import Footer from "@/components/footer/Footer.vue";

describe("In App Component", () => {
  let appWrapper;
  beforeEach(() => {
    Vue.use(Vuetify);
    Vue.use(VueRouter);
    appWrapper = shallowMount(App, {
      Vue
    });
  });
  afterEach(() => {
    appWrapper.destroy();
  });

  it("is a Vue instance", () => {
    expect(appWrapper.isVueInstance).toBeTruthy();
  });

  it("it should have a v-app", () => {
    expect(appWrapper.html()).toContain("v-app");
  });

  it("it should load the app-header", () => {
    expect(Header).toBeTruthy();
  });

  it("it should load the app-header", () => {
    expect(Footer).toBeTruthy();
  });

  it("it should have a v-content", () => {
    expect(appWrapper.html()).toContain("v-content");
  });
});
